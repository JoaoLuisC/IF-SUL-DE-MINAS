package javasorts;

public class ComaparaSorts {
    
    public static void ConfrontoSorts(){
        
        
        
    }
    
    
}
