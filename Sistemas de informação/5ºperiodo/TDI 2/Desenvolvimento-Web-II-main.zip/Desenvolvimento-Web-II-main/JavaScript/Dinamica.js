let myVar;
console.log(typeof myVar);

let sum = myVar + 1;
console.log(sum);
// NaN --> number + undefined
console.log(typeof sum);

let pi = 3.1415;
console.log(pi.toFixed(2));
