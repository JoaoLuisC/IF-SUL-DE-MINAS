let type10 = typeof (10);
console.log(type10); // number
console.log(typeof type10); // string

// if (typeof 10 == "numer")